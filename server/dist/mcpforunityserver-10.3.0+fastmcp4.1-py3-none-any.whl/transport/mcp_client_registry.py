"""Track MCP client connections and fan out ``tools/list_changed`` on FastMCP 4 / MCP SDK 2.

FastMCP 3 kept one ``MiddlewareServerSession`` per client, which plugin_hub used to patch so it
could collect live sessions. MCP SDK 2 builds a ``ServerSession`` per request; the per-client
object is ``mcp.server.connection.Connection`` (``session._connection``), and there are two kinds:

- Handshake clients (``initialize``: streamable HTTP with ``Mcp-Session-Id``, stdio) keep one
  Connection for the whole session and receive notifications on its standalone channel. We collect
  those here and call ``Connection.send_tool_list_changed()`` on them.
- 2026-07-28 clients send one self-contained POST per request (a fresh Connection each time, no
  back-channel). They opt in to server events with ``subscriptions/listen``; the SDK's
  ``ListenHandler`` serves that stream from a ``SubscriptionBus`` we publish ``ToolsListChanged`` to.
"""
from __future__ import annotations

import logging
import weakref
from typing import Any

from fastmcp.server.middleware import Middleware, MiddlewareContext

logger = logging.getLogger("mcp-for-unity-server")

LISTEN_METHOD = "subscriptions/listen"

# ``mcp.server.subscriptions`` is imported lazily: several test modules stub ``mcp`` with a
# bare module that only carries ``mcp.types``, and nothing here is needed before the server runs.
_connections: "weakref.WeakSet[Any]" = weakref.WeakSet()
_bus: Any | None = None
_listen_handler: Any | None = None
_installed_servers: "weakref.WeakSet[Any]" = weakref.WeakSet()


def _connection_of(fastmcp_ctx: Any) -> Any | None:
    """Return the SDK Connection behind a FastMCP Context, or None outside a live request."""
    if fastmcp_ctx is None:
        return None
    session = None
    request_ctx = getattr(fastmcp_ctx, "request_context", None)
    if request_ctx is not None:
        session = getattr(request_ctx, "session", None)
    if session is None:
        session = getattr(fastmcp_ctx, "_session", None)
    return getattr(session, "_connection", None)


def track_connection(connection: Any) -> bool:
    """Remember a connection that can receive server notifications. Returns True if newly added."""
    if connection is None or not getattr(connection, "has_standalone_channel", False):
        # Single-exchange (2026-07-28 HTTP) connections have no back-channel; they get events
        # through subscriptions/listen instead, so there is nothing to track.
        return False
    if connection in _connections:
        return False
    _connections.add(connection)
    exit_stack = getattr(connection, "exit_stack", None)
    if exit_stack is not None:
        ref = weakref.ref(connection)

        def _forget() -> None:
            conn = ref()
            if conn is not None:
                _connections.discard(conn)

        try:
            exit_stack.callback(_forget)
        except Exception:
            logger.debug("Could not register connection teardown callback", exc_info=True)
    return True


def tracked_connection_count() -> int:
    return len(_connections)


class McpClientTrackingMiddleware(Middleware):
    """Collect the Connection of every inbound message (initialize included)."""

    async def on_message(self, context: MiddlewareContext, call_next):
        try:
            track_connection(_connection_of(context.fastmcp_context))
        except Exception:
            logger.debug("MCP client tracking failed", exc_info=True)
        return await call_next(context)


def subscription_bus() -> Any:
    """The process-wide SubscriptionBus that ``subscriptions/listen`` streams are fed from."""
    global _bus
    if _bus is None:
        from mcp.server.subscriptions import InMemorySubscriptionBus
        _bus = InMemorySubscriptionBus()
    return _bus


def install(mcp: Any) -> None:
    """Register the tracking middleware and the ``subscriptions/listen`` handler once per server."""
    global _listen_handler
    if mcp in _installed_servers:
        return
    _installed_servers.add(mcp)
    mcp.add_middleware(McpClientTrackingMiddleware())
    low_level = getattr(mcp, "_mcp_server", None)
    if low_level is None:
        return
    if low_level.get_request_handler(LISTEN_METHOD) is None:
        try:
            from mcp.server.subscriptions import ListenHandler
            from mcp.types import SubscriptionsListenRequestParams
            if _listen_handler is None:
                _listen_handler = ListenHandler(subscription_bus())
            low_level.add_request_handler(LISTEN_METHOD, SubscriptionsListenRequestParams, _listen_handler)
            logger.debug("Registered %s handler for 2026-07-28 clients", LISTEN_METHOD)
        except Exception:
            # Server keeps working; 2026-07-28 clients just will not get tools/list_changed pushes.
            logger.warning("Could not register %s; tool-list change notifications for "
                           "2026-07-28 clients are disabled", LISTEN_METHOD, exc_info=True)


async def notify_tools_list_changed() -> int:
    """Tell every connected MCP client to re-fetch the tool list. Returns the number of
    handshake connections notified; listen streams are served through the bus."""
    connections = list(_connections)
    notified = 0
    for connection in connections:
        try:
            initialized = getattr(connection, "initialized", None)
            if initialized is not None and not initialized.is_set():
                continue
            await connection.send_tool_list_changed()
            notified += 1
        except Exception:
            logger.debug("Failed to notify MCP connection of tool list change", exc_info=True)
    try:
        from mcp.server.subscriptions import ToolsListChanged
        await subscription_bus().publish(ToolsListChanged())
    except Exception:
        logger.debug("Failed to publish ToolsListChanged to listen streams", exc_info=True)
    return notified


def close() -> None:
    """Gracefully end open listen streams (server shutdown)."""
    if _listen_handler is not None:
        try:
            _listen_handler.close()
        except Exception:
            logger.debug("Closing listen streams failed", exc_info=True)
